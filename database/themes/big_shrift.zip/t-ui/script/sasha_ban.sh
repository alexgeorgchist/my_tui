#!/bin/sh

SCRIPTNAME=${0##*/}
dir="/storage/emulated/0/t-ui/ascii"
logo="sasha.txt"
printf "`cat $dir/$logo`"
exit 0