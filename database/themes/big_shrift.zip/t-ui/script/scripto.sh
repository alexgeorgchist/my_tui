#!/bin/sh

SCRIPTNAME=${0##*/}

home=" /storage/emulated/0"
scriptdir="/storage/emulated/0/t-ui/script"
logos="/storage/emulated/0/t-ui/ascii"
line="++++++++++++++++++++++++++++"
line2=".............................................................."

## ARRAY LIST
mmlist=(mm.sh mmload.sh)
mmabout=(Выбор_themes Загрузка_mm)
scriptlist=(6p.sh info.sh pogoda.sh pokoypsaltir.sh sysinfo.sh) # Massiv tem
about=(Шестопсалмие Инфопамять Казань О_упокоении О_системе) #Opisanie

limit=${#scriptlist[@]} #Number of topics in the array list

menu_script() {
	printf "%s\n" \
	           "$line"\
               "              МОИ СКРИПТЫ:"
     printf "%-26s%s\n" \
               " a. ${mmlist[0]}" "${mmabout[0]}" \
               " b. ${mmlist[1]}" "${mmabout[1]}"
     printf "%s\n" $line2
var=1 # Number of topics in the array list LIMIT=${#THEME_LIST[@]}
    while [ "$var" -le "$limit" ] # <=
    do
    printf "%-26s%s\n" \
               " $var. ${scriptlist[$var-1]}" "${about[$var - 1]}"
var=`expr $var + 1` # Allowed var=$(($var+1)) or let "var += 1"
    done
    	printf "%s\n" \
	              "$line"
    	
    exit 0
}

going () {
sh ./$chosen
}

print_header () {
cat $logos/anonymous.txt
}

print_end () {
printf "   %-7s%s\n"\
          " " "Координаты заменены"\
          " " "    Restart"
}


## index=$(($1-1))
## CHOSEN_THEME="{THEME_LIST[$index]}"
case "$1" in
      a)
      chosen="${mmlist[0]} -l"
      cd $home
      going
      exit 0
      ;;
      b)
      chosen="${mmlist[1]}"
      cd $home
      going
      exit 0
      ;;
      [1-$limit])
      index=`expr $1 - 1` # Allowed index=$(($1-1))
  	chosen="${scriptlist[$index]}"
      cd $scriptdir
      going
      exit 0
      ;;
     *)
#        print_header
        menu_script
        exit 0
        ;;
esac