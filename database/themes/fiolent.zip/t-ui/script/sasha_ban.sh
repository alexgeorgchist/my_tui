#!/bin/sh

SCRIPTNAME=${0##*/}
dir="/storage/emulated/0/t-ui/ascii"
logo="sasha2_1str.txt"
printf "`cat $dir/$logo`"
exit 0