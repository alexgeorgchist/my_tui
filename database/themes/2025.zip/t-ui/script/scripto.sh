#!/bin/sh

SCRIPTNAME=${0##*/}

home=" /storage/emulated/0"
scriptdir="/storage/emulated/0/t-ui/script"
logos="/storage/emulated/0/t-ui/ascii"
line="+++++++++++++++++++++++++++++++++++++++"

## ARRAY LIST
mmlist=(mm.sh mmload.sh)
mmabout=(Выбор_themes Загрузка_mm)
scriptlist=(6p.sh info.sh pogoda.sh pokoypsaltir.sh sysinfo.sh top_custom_info.sh topinfo.sh) # Massiv tem
about=(Шестопсалмие Инфопамять Казань О_упокоении О_системе -/- -/-) #Opisanie

limit=${#scriptlist[@]} #Number of topics in the array list

menu_script() {
	printf "%s\n" \
	           "$line"\
               "              МОИ СКРИПТЫ:"
               
    printf "%-26s%s\n" \
               " a. ${mmlist[0]}" "${mmabout[0]}" \
               " b. ${mmlist[1]}" "${mmabout[1]}"
var=1 # Number of topics in the array list LIMIT=${#THEME_LIST[@]}
    while [ "$var" -le "$limit" ] # <=
    do
    printf "%-26s%s\n" \
               " $var. ${scriptlist[$var-1]}" "${about[$var - 1]}"
var=`expr $var + 1` # Allowed var=$(($var+1)) or let "var += 1"
    done
    	printf "%s\n" \
	              "$line"
    	
    exit 0
}

going1 () {
cd $home
sh ./$chosen
}

going2 () {
cd $scriptdir
sh ./$chosen
}


print_header () {
cat $logos/anonymous.txt
}

print_end () {
printf "   %-7s%s\n"\
          " " "Координаты заменены"\
          " " "    Restart"
}


## index=$(($1-1))
## CHOSEN_THEME="{THEME_LIST[$index]}"
case "$1" in
      a)
      chosen="${mmlist[0]} -l"
      echo $chosen
      going1
      ;;
      b)
      chosen="${mmlist[1]}"
      going1
      ;;
      [1-$limit])
      index=`expr $1 - 1` # Allowed index=$(($1-1))
  	chosen="${scriptlist[$index]}"
      going2
      exit 0
      ;;
     *)
        printf "%s\n" $line
        print_header
        menu_script
        exit 0
        ;;
esac