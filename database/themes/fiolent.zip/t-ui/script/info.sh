#!/system/bin/sh
## Author  	: AGCH
## Github  	: @alexgeorgchist
## 26.01.2023
## Thanks to @deadrabbit404

PROGNAME=${0##*/}
TUI="/storage/emulated/0/t-ui"
LOGO=" /storage/emulated/0/t-ui/ascii/inf.txt"
line1="========================================"
line2="----------------------------------------"


MEMTOTAL=`grep MemTotal /proc/meminfo | awk '{ print $2 }'`
MEMAVAIL=`grep MemAvail /proc/meminfo | awk '{ print $2 }'`
MEMPERC=$(awk "BEGIN {print ($MEMAVAIL/$MEMTOTAL)*100}")
MEMPERCROUND=$(echo $MEMPERC | awk '{printf("%.2f \n",$1)}') # krugl posle zapatoy

# Truncate those having 0 values from output of `uptime -p`
UPTIME=`uptime -p | sed "s/ 0 [^ ]*,//g" | sed "s/up //" | sed "s/week/нед/" | sed "s/days/д/" | sed "s/day/д/" | sed "s/hours/ч/" | sed "s/minutes/мин/"`
# The time has been up
BEENTIMEUP=`uptime -s`


#Read psalms for everydays
everyday_psalm () {
DIR="/storage/emulated/0//t-ui/script_texts"
TXT1="$DIR/numdate.txt"
TXT2="$DIR/numpsalm.txt"
NOWTIME=`date +%j` #Number day of the year (001-365)
if [[ ! -f $TXT1 ]] || [[ ! -f $TXT2 ]]
    then echo " !!! Надо вписать номер сегодняшней кафизмы в numpsalm.txt в папке script_texts"
             echo $NOWTIME > $DIR/numdate.txt
             echo 1 > $DIR/numpsalm.txt
             exit 0
fi
LASTTIME=`cat $DIR/numdate.txt`
    let "RAZN = $NOWTIME - $LASTTIME"

LASTPSALM=`cat $DIR/numpsalm.txt`
    let "PSALM = $LASTPSALM + $RAZN"

if [ "$PSALM" -gt 20 ] # >20
    then let "PSALM = $PSALM - 20"
fi

echo $NOWTIME > $DIR/numdate.txt
echo $PSALM > $DIR/numpsalm.txt

    padding=16
    printf "   %-${padding}s : %-s\n"\
              " " " "\
              "Today" "$PSALM кафисма"
}

sorokoust () {
D=`date +%j`
let "DD = $D - 126" # Set 126 or another for a first day
N="Valentina"

padding=16
if [ "$DD" -ge 1 ] && [ "$DD" -le 40 ] # >=1 & <=40
    then printf "   %-${padding}s : %-s\n"\
                       " " " " \
                       "$N" "$DD" # Set name
    else printf "   %-${padding}s : %-s\n"\
                        "Sorokoust" "noname"
fi
}



# Determine SELinux status without root access
cat /sys/fs/selinux/enforce >/dev/null 2>&1
[ $? -eq 0 ] && SELINUX="Permissive" || SELINUX="Enforcing"



    
print_logo () {
# Print distro ascii art logo
    cat $LOGO
    printf "\n"
}

print_line1 () {
    printf $line1
    printf "\n"
}

print_line2 () {
    printf $line2
    printf " \n"
}

# !!! Read Psaltir
psaltir_papa_mama_brat () {
DATENOW=`date +%j` #Number day of the year xxx-format
GOD=`date +%Y`

dp=(110 102 122 107) # день Пасхи 20апр2025 11апр2026 2мая2027 16апр2028
let "k = $GOD - 2025"
let "BEGINDAY = ${dp[$k]} - 48" # Пасха - 40 - страстная

let "KRUG1 = $BEGINDAY + 20"
let "KRUG2 = $BEGINDAY +40"
let "KRUG3 = $BEGINDAY +60"
let "KRUG4 = $BEGINDAY +80"
let "KRUG5 = $BEGINDAY +120"

let "READ = $DATENOW - $BEGINDAY"
if [ "$DATENOW" -ge "$BEGINDAY" ] && [ "$DATENOW" -lt "$KRUG1" ]
then let "READ = $READ + 1"; x=1
  elif [ "$DATENOW" -ge "$KRUG1" ] && [ "$DATENOW" -lt "$KRUG2" ] # >= && <
  then let "READ = $READ - 19"; x=2 #  + 1 - 20
    elif [ "$DATENOW" -ge "$KRUG2" ] && [ "$DATENOW" -lt "$KRUG3" ]
    then let "READ = $READ - 39"; x=3 #  + 1 - 40
      elif [ "$DATENOW" -ge "$KRUG3" ] && [ "$DATENOW" -lt "$KRUG4" ]
      then let "READ = $READ - 59"; x=4 #  + 1 - 60
        elif [ "$DATENOW" -ge "$KRUG4" ] && [ "$DATENOW" -lt "$KRUG5" ]
        then let "READ = $READ - 79"b x=5 #  + 1 - 80             
elif [ "$DATENOW" -ge "KRUG5" ]
then let "X = $DATENOW - 365" && let "READ = $X - $BEGINDAY"
  elif [ "$READ" -eq -1 ] # = -1
  then READ="zavtra"
fi

if [ "$DATENOW" -ge "$BEGINDAY" ] && [ "$DATENOW" -lt 156 ] || [ "$DATENOW" -ge 284 ] && [ "$DATENOW" -lt 324 ] # papa -40 i do 5 june; brat -40 i do 20 november
then READ=`echo $READ | sed "s/-//"` # delete minus in the number
printf "  %-${padding1}s : %-${padding2}s\n"\
          "PapaMamaBrat" "$READ kafisma $x krug"
fi                 
}


print_info () {
# Print all the information
    padding=14
    printf "%-${padding}s : %-s\n"\
        "Available" "$((MEMAVAIL/1024)) MiB  $MEMPERCROUND%"\
        "Total" "$((MEMTOTAL/1024)) MiB"\
        "Up time" "$BEENTIMEUP"\
        " " "$UPTIME"
#        printf "%${padding}s : %s\n" "Public IPv4" `get_public_ip`
}




notes () {
padding=10
cd $TUI
    NOTEFILE=$(sed -e 's/<?xml version="1.0" encoding="UTF-8"?>//; s/<NOTES>//; s/<note creationTime="//; s/" value="//; s/" lock="false"\/>//; s/<\/NOTES>//; s/^.............//w notefile.txt' notes.xml)
    abc=notefile.txt
x=0
while IFS= read -r string; do
           let "x = $x + 1"
done < notefile.txt
    
if [ -z "$( cat ${abc} )" ]  # if file is empty (pustoy)
    then 
             BLOKNOT="✓ Нет записей."
             printf "    %-${padding}s : %-s\n"\
                        "NOTES:" "$BLOKNOT"
    else 
             BLOKNOT=" "
               
x=1
    printf "   %-${padding}s%-s\n"\
              "Напоминаю:" " " 
while IFS= read -r string; do
    printf " %s%s\n"\
           "$x." "$string"
           let "x = $x + 1"
done < notefile.txt
fi
}
# Script starts here

print_line1
print_logo
print_info
print_line2
#sorokoust
psaltir_papa_mama_brat
notes
print_line1







