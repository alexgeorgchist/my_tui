#!/bin/sh

line1="===== ПОГОДА СЕЙЧАС ======="
line2="============================="
weather=`curl -s http://wttr.in/Казань?0MT`

    echo "$line1"
    echo " "
    echo "$weather"
    echo "$line2"
exit 0
